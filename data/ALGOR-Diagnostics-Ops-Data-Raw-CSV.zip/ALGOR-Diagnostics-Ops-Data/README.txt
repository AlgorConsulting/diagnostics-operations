Diagnostics Centre Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  ops_monthly: 5,342 rows
  pts_monthly: 3,083 rows
  std_monthly: 3,765 rows
  rej_monthly: 4,266 rows
  logi_monthly: 753 rows
  budget_monthly: 93 rows
  centre_daily_log: 14,166 rows
  department_daily_by_zone: 12,738 rows
  late_reports_sample: 22,006 rows
  sample_rejections_sample: 2,453 rows
